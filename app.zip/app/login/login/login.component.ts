import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

const ROOT_ROUTE = '/';
const STORAGE_MSISDN = 'roaming.msisdn';
const MSISDN = '0767778242';

@Component({
  selector: 'sr-login',
  templateUrl: 'login.component.html',
  styleUrls: ['login.component.scss']
})
export class LoginComponent implements OnInit {

  msisdn: string = MSISDN;

  constructor(private router: Router) {
  }

  ngOnInit() {
  }

  login() {
    localStorage.setItem(STORAGE_MSISDN, this.msisdn);
    this.router.navigate([ROOT_ROUTE]);
  }

}

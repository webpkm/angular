import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'sr-options-category',
  templateUrl: 'options-category.component.html',
  styleUrls: ['options-category.component.scss']
})
export class OptionsCategoryComponent implements OnInit {

  options;
  category;

  /* Dummy data. TODO: service integration */
  model = {
    travelData: [
      { offer : 'Hero Offer', value: '100', units: 'MB', price: '9'},
      { offer : 'Unlimited', value: '1', units: 'GB', price: '69'},
      { offer : 'Hero Offer', value: '300', units: 'MB', price: '25'},
      { offer : 'Unimited Offer', value: '5', units: 'GB', price: '89'},
      { offer : 'Hero Offer', value: '10', units: 'GB', price: '99'}
    ],
    travelDays: [
      { offer : 'Hero Offer', value: '30', units: 'days', price: '69'},
      { offer : 'Unimited Offer', value: '7', units: 'days', price: '29'},
      { offer : 'Unimited Offer', value: '3', units: 'days', price: '19'}
    ]
  };

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    /* get category from url */
    this.category = this.route.snapshot.paramMap.get('category');

    if ( this.category === 'data') {
      this.options = this.model.travelData;
    } else if ( this.category === 'days') {
      this.options = this.model.travelDays;
    }
  }

}

import { TestBed, inject } from '@angular/core/testing';

import { OptionsService } from './options.service';
import { ApolloService } from '../../../core/apollo.service';
import { AuthService } from '../../../core/auth.service';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { Router } from '@angular/router';

describe('OptionsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [OptionsService, ApolloService, AuthService, HttpClient, HttpHandler, {
        provide: Router,
        useClass: class { navigate = jasmine.createSpy('navigate'); }
      }]
    });
  });

  it('should be created', inject([OptionsService], (service: OptionsService) => {
    expect(service).toBeTruthy();
  }));
});

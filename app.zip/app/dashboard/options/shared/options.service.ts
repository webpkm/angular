import { Injectable } from '@angular/core';
import { ApolloService } from '../../../core/apollo.service';

import gql from 'graphql-tag';
import { Observable } from 'rxjs/Observable';
import { OptionModel } from '../../../shared/model/option.model';

const getAllOptions = gql`
query getAllOptions{
  subscriber{
		options{
      name
      activatedAt
      conflictsWith
      dependsOn
      buckets{
        name
        active
        activatedAt
        expiresAt
        initial
        available
        measureUnit
        credits
      }
    }
  }
}`;

export interface OptionsResponse {
  options: OptionModel[];
}

@Injectable()
export class OptionsService {
  constructor(private apollo: ApolloService) { }

    public getAllOptions(): Observable<OptionModel[]> {
      return this.apollo.watchQuery<OptionsResponse>({query: getAllOptions})
      .map(value => value.data.options);
    }


}

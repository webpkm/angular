import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sr-options',
  templateUrl: './options.component.html',
  styleUrls: ['./options.component.scss']
})
export class OptionsComponent implements OnInit {

  /* Dummy data. TODO: service integration */
  model = {
    travelData: [
      { id: '10', offer : 'Hero Offer!', value: '100', units: 'MB', price: '9'},
      { id: '11', offer : 'Unlimited!', value: '1', units: 'GB', price: '79'},
      { id: '12', offer : 'Hero Offer!', value: '300', units: 'MB', price: '25'},
      { id: '13', offer : 'Unimited Offer!', value: '5', units: 'GB', price: '149'},
      { id: '14', offer : 'Hero Offer!', value: '10', units: 'GB', price: '249'}
    ],
    travelDays: [
      { id: '20', offer : 'Hero Offer!', value: '30', units: 'days', price: '69'},
      { id: '21', offer : 'Unimited Offer!', value: '7', units: 'days', price: '29'},
      { id: '21', offer : 'Unimited Offer!', value: '3', units: 'days', price: '19'}
    ]
  };

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sr-history',
  templateUrl: 'history.component.html',
  styleUrls: [ 'history.component.scss' ]
})

export class HistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

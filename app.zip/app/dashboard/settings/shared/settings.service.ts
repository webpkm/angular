import { Injectable } from '@angular/core';
import { ApolloService } from '../../../core/apollo.service';
import gql from 'graphql-tag';
import { Observable } from 'rxjs/Observable';

import { SubscriberModel } from '../../../shared/model/subscriber.model';
import { SettingsModel } from '../../../shared/model/settings.model';

const getAllSubscriberSettings = gql`
query getAllSubscriberSettings{
  subscriber{
    settings{
      redirectToMailBoxAbroad{
        value
        modifiable
      }
      seaAndAirSatelliteTraffic{
        value
        modifiable
      }
      noDataRoamingOutsideBucket{
        value
        modifiable
      }
      roamingInfoSms{
        value
        modifiable
      }
      monthlyLimit
    }
  }
}`;

export interface SubscriberResponse {
  subscriber: SubscriberModel;
}

@Injectable()
export class SettingsService {

  constructor(private apollo: ApolloService) { }

  public getAllSubscriberSettings(): Observable<SettingsModel> {
    return this.apollo.watchQuery<SubscriberResponse>({query: getAllSubscriberSettings})
    .map(value => value.data.subscriber.settings);
  }

}

import { TestBed, inject } from '@angular/core/testing';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { Router } from '@angular/router';

import { ApolloService } from '../../../core/apollo.service';
import { AuthService } from '../../../core/auth.service';
import { SettingsService } from './settings.service';

describe('SettingsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        SettingsService, ApolloService, AuthService, HttpClient, HttpHandler, {
        provide: Router,
        useClass: class { navigate = jasmine.createSpy('navigate'); }
    }]
    });
  });

  it('should be created', inject([SettingsService], (service: SettingsService) => {
    expect(service).toBeTruthy();
  }));
});

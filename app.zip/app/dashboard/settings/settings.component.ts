import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatSnackBar, MatSelectionListChange } from '@angular/material';
import { Subscription } from 'rxjs/Subscription';
import { SettingsModel } from '../../shared/model/settings.model';
import { SettingsService } from './shared/settings.service';

const NO_LIMIT = 2000;
const MESSAGE_DURATION = 2000;

@Component({
  selector    : 'sr-settings',
  templateUrl : 'settings.component.html',
  styleUrls   : ['settings.component.scss']
})

export class SettingsComponent implements OnInit, OnDestroy {
  settings: SettingsModel;
  subscriber: Subscription;
  monthlyLimit: any;
  sliderValue;

  constructor(private snackBar: MatSnackBar,
              private settingsService: SettingsService) { }

  ngOnInit() {
    this.subscriber = this.settingsService.getAllSubscriberSettings()
    .subscribe(value => {
        this.settings = value;
        this.setInitialSliderValue(this.settings.monthlyLimit);
    });
  }

  ngOnDestroy() {
    this.subscriber.unsubscribe();
  }

  settingChanged(event: MatSelectionListChange) {
    this.openSnackBar('Setting Updated', 'UNDO');
  }

  setInitialSliderValue(val: number) {
    this.monthlyLimit = val;

    if (val > 1000) {
      this.sliderValue = 8;
    } else if (val > 640) {
      this.sliderValue = 7;
    } else if (val > 320) {
      this.sliderValue = 6;
    } else if (val > 160) {
      this.sliderValue = 5;
    } else if (val > 80) {
      this.sliderValue = 4;
    } else if (val > 40) {
      this.sliderValue = 3;
    } else if (val > 20) {
      this.sliderValue = 2;
    } else if (val > 10) {
      this.sliderValue = 1;
    }
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: MESSAGE_DURATION,
    });
  }

  onModelChange(value) {
    let cost = 10;
    switch (value) {
      case 0 : cost = 10; break;
      case 1 : cost = 20; break;
      case 2 : cost = 40; break;
      case 3 : cost = 80; break;
      case 4 : cost = 160; break;
      case 5 : cost = 320; break;
      case 6 : cost = 640; break;
      case 7 : cost = 1000; break;
      case 8 : cost = 2000; break;
    }

    if (cost === NO_LIMIT) {
      this.monthlyLimit = 'No Limit';
    } else {
      this.monthlyLimit = cost;
    }
  }
}

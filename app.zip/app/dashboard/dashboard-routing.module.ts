import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HistoryComponent } from './history/history.component';
import { OptionsComponent } from './options/options.component';
import { OptionsCategoryComponent } from './options-category/options-category.component';
import { SettingsComponent } from './settings/settings.component';

const routes: Routes = [
  { path: '', redirectTo: '/options', pathMatch: 'full'   },
  { path: 'options', component: OptionsComponent },
  { path: 'options/:category', component: OptionsCategoryComponent  },
  { path: 'history', component: HistoryComponent  },
  { path: 'settings', component: SettingsComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }

import { Component, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';


@Component({
    selector: 'sr-option-detail',
    templateUrl: './option-detail.component.html',
    styleUrls: ['./option-detail.component.scss']
})
export class OptionDetailComponent {

    constructor(public dialogRef: MatDialogRef<OptionDetailComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any) { }

    onNoClick(): void {
        this.dialogRef.close();
    }
}

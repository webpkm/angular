import { Component, OnInit, Input } from '@angular/core';

import { MatDialog, MatDialogRef } from '@angular/material';

import { OptionDetailComponent } from '../option-detail/option-detail.component';
import { Router } from '@angular/router';


@Component({
  selector: 'sr-option',
  templateUrl: 'option.component.html',
  styleUrls: ['option.component.scss']
})
export class OptionComponent implements OnInit {

  @Input()
  option;
  optionDetailId;
  optionDetail;
  dialogRef;

  constructor(private router: Router,
    public dialog: MatDialog) { }

  ngOnInit() {
  }
  openDialog(optionDetailId: string): void {
    this.optionDetailId = optionDetailId;
    /*TODO: Service Integration to get option details*/
    if (this.optionDetailId < 20 ) {
      this.optionDetail = { id: '10', offer : 'Hero Offer!', value: '100', units: 'MB', price: '9'};
    } else {
      this.optionDetail = { id: '20', offer : 'Hero Offer!', value: '30', units: 'days', price: '69'};
    }

    this.dialogRef = this.dialog.open(OptionDetailComponent, {
      width: '100vw',
      height: '100vh',
      maxWidth: '100vw',
      data: { optionDetail: this.optionDetail }
    });

    this.dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed', result);
    });
  }


}

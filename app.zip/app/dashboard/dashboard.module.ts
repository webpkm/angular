import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule } from '@angular/material';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { SharedModule } from '../shared/shared.module';
import { HistoryComponent } from './history/history.component';
import { OptionsComponent } from './options/options.component';
import { OptionsCategoryComponent } from './options-category/options-category.component';

import { OptionComponent } from './option/option.component';
import { SettingsComponent } from './settings/settings.component';
import { SettingsService } from './settings/shared/settings.service';

import { OptionDetailComponent } from './option-detail/option-detail.component';




@NgModule({
    imports: [
        CommonModule,
        DashboardRoutingModule,
        SharedModule,
        MatDialogModule
    ],
    declarations: [
        OptionsComponent,
        OptionsCategoryComponent,
        HistoryComponent,
        OptionComponent,
        SettingsComponent,
        OptionDetailComponent
    ],
    entryComponents: [OptionDetailComponent],
    providers: [SettingsService]
})
export class DashboardModule { }

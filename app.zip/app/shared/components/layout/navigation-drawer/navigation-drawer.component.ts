import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sr-navigation-drawer',
  templateUrl: 'navigation-drawer.component.html',
  styleUrls: ['navigation-drawer.component.scss']
})
export class NavigationDrawerComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }
}

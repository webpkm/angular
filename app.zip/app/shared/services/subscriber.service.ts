import { Injectable } from '@angular/core';
import { ApolloService } from '../../core/apollo.service';
import gql from 'graphql-tag';
import { Observable } from 'rxjs/Observable';
import { SubscriberModel } from '../../shared/model/subscriber.model';

const getSubscriberQuery = gql`
query getSubscriberModel{
  subscriber{
    msisdn
    companyName
  }
}`;

export interface SubscriberResponse {
  subscriber: SubscriberModel;
}

@Injectable()
export class SubscriberService {

  constructor(private apollo: ApolloService) { }

  public getSubscriber(): Observable<SubscriberModel> {
    return  this.apollo.watchQuery<SubscriberResponse>({query: getSubscriberQuery})
                .map(value => value.data.subscriber);
  }

}

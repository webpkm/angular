import { TestBed, inject } from '@angular/core/testing';
import { ApolloService } from '../../core/apollo.service';
import { AuthService } from '../../core/auth.service';
import { HttpClient } from '@angular/common/http';
import { HttpHandler } from '@angular/common/http';
import { Router } from '@angular/router';
import { SubscriberService } from './subscriber.service';

describe('SubscriberService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        SubscriberService, ApolloService, AuthService, HttpClient, HttpHandler, {
        provide: Router,
        useClass: class { navigate = jasmine.createSpy('navigate'); }
    }]
    });
  });

  it('should be created', inject([SubscriberService], (service: SubscriberService) => {
    expect(service).toBeTruthy();
  }));

});

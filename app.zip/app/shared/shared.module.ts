import { CdkTableModule } from '@angular/cdk/table';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatCardModule,
  MatCheckboxModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatProgressBarModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  DateAdapter,
  NativeDateAdapter
} from '@angular/material';
import { LayoutNavComponent } from './components/layout/layout-nav/layout-nav.component';
import { LayoutComponent } from './components/layout/layout.component';
import { NavigationDrawerComponent } from './components/layout/navigation-drawer/navigation-drawer.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SubscriberService } from './services/subscriber.service';

const ANGULAR_MODULE: any[] = [
  FormsModule,
  ReactiveFormsModule
];

const ANGULAR_LAYOUT_MODULE: any[] = [
  FlexLayoutModule
];

const MATERIAL_MODULES: any[] = [
  CdkTableModule,
  MatButtonModule,
  MatCardModule,
  MatCheckboxModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatProgressBarModule,
  MatSelectModule,
  MatSliderModule,
  MatSidenavModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule
];

const LAYOUT_COMPONENTS: any[] = [
  LayoutComponent,
  LayoutNavComponent,
  NavigationDrawerComponent
];

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    ANGULAR_MODULE,
    ANGULAR_LAYOUT_MODULE,
    MATERIAL_MODULES
  ],
  declarations: [LAYOUT_COMPONENTS],
  providers: [
    { provide: DateAdapter, useClass: NativeDateAdapter },
    SubscriberService
  ],
  exports: [
    ANGULAR_MODULE,
    ANGULAR_LAYOUT_MODULE,
    MATERIAL_MODULES,
    LAYOUT_COMPONENTS
  ]
})
export class SharedModule {
}

import {SettingsModel} from './settings.model';

export class SubscriberModel {
  msisdn: string;
  companyName: string;
  settings: SettingsModel;
}

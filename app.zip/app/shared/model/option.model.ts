import { BucketModel } from './bucket.model';

export class OptionModel {
  name: string;
  status: OptionStatus;
  active: boolean;
  activatedAt: string;
  modifiable: boolean;
  conflictsWith: string[];
  dependsOn: string;
  earliestDeactivationAt: string;
  scheduledDeactivationAt: string;
  buckets: BucketModel[];
}

export enum OptionStatus {
  RECURRING = 'RECURRING',
  EXPIRING = 'EXPIRING',
  SUSPENDED = 'SUSPENDED',
  WAITING = 'WAITING',
  UNINSTALLED = 'UNINSTALLED'
}

export class SettingsModel {
  redirectToMailBoxAbroad: SettingAttribute;
  seaAndAirSatelliteTraffic: SettingAttribute;
  noDataRoamingOutsideBucket: SettingAttribute;
  roamingInfoSms: SettingAttribute;
  monthlyLimit: number;
}

export interface SettingAttribute {
  value: string;
  modifiable: boolean;
}

export class BucketModel {
    name: string;
    active: boolean;
    activatedAt: string;
    expiresAt: string;
    initial: number;
    available: number;
    measureUnit: BucketMeasureUnit;
    credits: BucketCredit[];
}

export enum BucketMeasureUnit {
    SECOND = 'SECOND',
    MINUTE = 'MINUTE',
    SMS = 'SMS',
    MMS = 'MMS',
    KB = 'KB',
    MB = 'MB',
    GB = 'GB'
}

export enum BucketCredit {
    DATA = 'DATA',
    SMS = 'SMS',
    MMS = 'MMS',
    VOICE = 'VOICE'
}

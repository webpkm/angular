import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { SubscriberModel } from '../shared/model/subscriber.model';
import { SubscriberService } from '../shared/services/subscriber.service';

@Component({
  selector: 'sr-main',
  templateUrl: 'main.component.html',
  styleUrls: ['main.component.scss'],
})
export class MainComponent implements OnInit, OnDestroy {

    subscriberSubscription: Subscription;
    subscriber: SubscriberModel;

        userRoutes = [
        {
            title: 'Home',
            route: '/',
            icon: 'home',
        },
        {
            title: 'Buy Travel Packages',
            route: '/',
            icon: 'language',
        },
        {
            title: 'View Usage Status',
            route: '/',
            icon: 'data_usage',
        },
        {
            title: 'Purchase History',
            route: '/history',
            icon: 'history',
        },
        {
            title: 'Change Language',
            route: '/',
            icon: 'translate',
        },
        {
            title: 'Roaming Settings',
            route: '/settings',
            icon: 'tune',
        },
        {
            title: 'FAQs',
            route: '/',
            icon: 'help_outline',
        },
        {
            title: 'Logout',
            route: '/',
            icon: 'exit_to_app',
        }
    ];

    adminRoutes = [
        {
            title: 'User Management',
            route: '/admin/users',
            icon: 'people',
        }, {
            title: 'Administration',
            route: '/',
            icon: 'widgets'
        }
    ];

    devRoutes = [
        {
            title: 'Documentation',
            route: '/docs',
            icon: 'book',
        }
    ];

    otherRoutes = [
        {
            title: 'Settings',
            route: '/',
            icon: 'settings',
        }, {
            title: 'Help',
            route: '/',
            icon: 'help'
        }
    ];

  constructor(private _router: Router,
              private subscriberService: SubscriberService) {}

  ngOnInit() {
    this.subscriberSubscription = this.subscriberService.getSubscriber()
    .subscribe(value => {
        this.subscriber = value;
    });
  }

  ngOnDestroy() {
    this.subscriberSubscription.unsubscribe();
  }
}

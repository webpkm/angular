import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthModule } from './auth/auth.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CoreModule } from './core/core.module';
import { LoginModule } from './login/login.module';
import { MainComponent } from './main/main.component';
import { SharedModule } from './shared/shared.module';
import { HttpClientModule } from '@angular/common/http';
import 'hammerjs';
import './rxjs-operators';
import { ConfirmationDialogComponent} from './shared/components/dialog/confirmation-dialog/confirmation-dialog.component';

@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    CoreModule,
    AppRoutingModule,
    SharedModule,
    AuthModule.forRoot(),
    LoginModule
  ],
  declarations: [
    AppComponent,
    MainComponent,
    DashboardComponent,
    ConfirmationDialogComponent],
  entryComponents: [
    ConfirmationDialogComponent
  ],
  providers: [
    { provide: LocationStrategy, useClass: HashLocationStrategy }
  ],
  bootstrap: [ AppComponent ]
})
export class AppModule {
}

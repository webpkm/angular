import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { AuthModule } from '../auth/auth.module';
import { DocsRoutingModule } from './docs-routing.module';
import { DocsComponent } from './docs.component';
import { ChartsComponent } from './charts/charts.component';

@NgModule({
    imports: [
        SharedModule,
        CommonModule,
        DocsRoutingModule,
        AuthModule
    ],
    declarations: [DocsComponent, ChartsComponent],
    entryComponents: [],
    providers: []
})
export class DocsModule {
}

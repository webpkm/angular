import { Component, OnInit } from '@angular/core';

export interface DocItem {
    id: string;
    name: string;
    examples?: string[];
}

export interface DocCategory {
    id: string;
    name: string;
    items: DocItem[];
    summary?: string;
}


@Component({
    selector: 'sr-docs',
    templateUrl: 'docs.component.html',
    styleUrls: ['docs.component.scss']
})
export class DocsComponent implements OnInit {

    public docCategories: DocCategory[] = [
        {
            id: 'layout',
            name: 'Layout',
            items: [
                {
                    id: 'layout',
                    name: 'Layout'
                },
                {
                    id: 'layout-nav',
                    name: 'Layout Nav'
                },
                {
                    id: 'navigation-drawer',
                    name: 'Navigation Drawer'
                }
            ]
        },
        {
            id: 'other',
            name: 'Other',
            items: [
              {
                id: 'charts',
                name: 'Charts'
              }
            ]
        },
    ];

    constructor() {
    }

    ngOnInit() {
    }
}

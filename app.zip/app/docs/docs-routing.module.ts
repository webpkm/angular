import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DocsComponent } from './docs.component';
import { ChartsComponent } from './charts/charts.component';

const usersRoutes: Routes = [
    {
      path: '', component: DocsComponent,
      children: []
    },
    {
      path: 'charts', component: ChartsComponent,
      children: []
  }
];

@NgModule({
    imports: [RouterModule.forChild(usersRoutes)],
    exports: [RouterModule]
})
export class DocsRoutingModule {
}

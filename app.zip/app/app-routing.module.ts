import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login/login.component';
import { MainComponent } from './main/main.component';

@NgModule({
  imports: [
    RouterModule.forRoot([
      {
        path: 'login', component: LoginComponent
      },
      {
        path: '', component: MainComponent,
        children: [
          {
            path: '', loadChildren: './dashboard/dashboard.module#DashboardModule'
          },
          {
            path: 'admin', loadChildren: './admin/admin.module#AdminModule'
          },
          {
            path: 'docs', loadChildren: './docs/docs.module#DocsModule'
          }
        ]
      },
    ], { preloadingStrategy: PreloadAllModules })
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {
}
